import { View, Text, Image, TouchableOpacity, ScrollView } from "react-native";
import React from "react";
import { useRouter } from "expo-router";
import useAuth from "../../hooks/useAuth";
import { Colors } from "../../constants/Colors";
import { StatusBar } from "expo-status-bar";

const Intro = ({ recipe }) => {
  const router = useRouter();
  const { user } = useAuth();
  return (
    <View
      style={{
        backgroundColor: Colors.WHITE,
      }}
    >
      <View
        style={{
          position: "absolute",
          zIndex: 1,
          display: "flex",
          flexDirection: "row",
          justifyContent: "flex-start",
          alignItems: "center",

          width: "100%",
          marginTop: 22,
        }}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            width: 60,
            height: 60,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Image
            source={require("../../assets/icons/arrow.png")}
            style={{
              width: 27,
              height: 27,
            }}
          />
        </TouchableOpacity>
        <Text
          style={{
            fontFamily: "fBold",
            fontSize: 25,
            marginLeft: "18%",
            color: Colors.RED,
          }}
        >
          DETAYLAR
        </Text>
      </View>
      <Image
        source={{ uri: recipe?.imageUrl }}
        style={{
          borderTopLeftRadius: 30,
          borderTopRightRadius: 30,
          marginTop: "19%",
          width: "100%",
          height: 250,
        }}
      />

      <ScrollView
        style={{
          marginTop: -30,
          borderTopLeftRadius: 30,
          borderTopRightRadius: 30,
          backgroundColor: Colors.WHITE,
        }}
      >
        <View
          style={{
            backgroundColor: Colors.WHITE,
          }}
        >
          <Text
            style={{
              fontFamily: "fBold",
              fontSize: 30,
              textAlign: "center",
              padding: 20,
              color: Colors.RED,
            }}
          >
            {recipe?.name}
          </Text>
        </View>
        <View
          style={{
            backgroundColor: Colors.WHITE,
          }}
        >
          <Text
            style={{
              fontFamily: "fBold",
              fontSize: 20,
              textAlign: "center",

              color: Colors.GRAY,
            }}
          >
            {recipe?.category}
          </Text>
        </View>
      </ScrollView>
      <StatusBar backgroundColor={Colors.WHITE} style="dark" />
    </View>
  );
};

export default Intro;
