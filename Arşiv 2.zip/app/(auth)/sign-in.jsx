import {
  View,
  Text,
  ScrollView,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  Image,
} from "react-native";
import React, { useState } from "react";
import CustomButton from "../../components/CustomButton";
import { Colors } from "../../constants/Colors";
import { router } from "expo-router";
import { useGlobalContext } from "../../context/GlobalProvider";
import { signIn } from "../../database/firebaseIslem";
import { icons } from "../../constants/icons";

const SignIn = () => {
  const [showPassword, setShowPassword] = useState(false);
  const { email, setEmail, password, setPassword } = useGlobalContext();

  const logIn = () => {
    signIn(email, password);
    setEmail("");
    setPassword("");
  };
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={{ flex: 1 }}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <ScrollView
          style={{
            height: 1000,
          }}
        >
          <ImageBackground
            source={require("../../assets/images/food19.jpg")}
            style={{ width: "100%", height: "100%", top: 0 }}
          >
            <View
              style={{
                gap: "7%",
                marginTop: "50%",
                borderTopRightRadius: 50,
                borderTopLeftRadius: 50,
                backgroundColor: Colors.WHITE,
                height: 700,
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  marginVertical: "5%",
                  fontFamily: "fExtraBold",
                  fontSize: 40,
                  textAlign: "center",
                  color: Colors.RED,
                }}
              >
                YEMEK{"\n"}TARİFLERİ
              </Text>
              <View
                style={{
                  padding: 17,
                  borderRadius: 20,
                  borderWidth: 3,
                  borderColor: Colors.YELLOW,
                  marginTop: 2,
                  width: "80%",
                  marginBottom: "10%",
                }}
              >
                <TextInput
                  placeholder="Emailiniz..."
                  title="email"
                  placeholderTextColor="rgba(0,0,0,0.3)"
                  value={email}
                  onChangeText={(text) => setEmail(text)}
                />
              </View>
              <View
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  padding: 17,
                  borderRadius: 20,
                  borderWidth: 3,
                  borderColor: Colors.YELLOW,
                  marginTop: 2,
                  width: "80%",
                  marginBottom: "10%",
                }}
              >
                <TextInput
                  placeholder="Şifreniz..."
                  title="password"
                  placeholderTextColor="rgba(0,0,0,0.3)"
                  value={password}
                  secureTextEntry={!showPassword}
                  onChangeText={(text) => setPassword(text)}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  style={{
                    position: "absolute",
                    top:10,
                    right: 10,
                    padding: 5,
                  }}
                >
                  <Image
                    source={
                      showPassword
                        ? require("../../assets/icons/eyehide.png")
                        : require("../../assets/icons/eye.png")
                    }
                    style={{ width: 24, height: 24,opacity:0.2 }}
                  />
                </TouchableOpacity>
              </View>
              <CustomButton title="Giriş Yap" handlePress={logIn} />
              <View
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Text
                  style={{
                    fontFamily: "fMedium",
                    marginTop: 30,
                  }}
                >
                  Hesabın yok mu ?{" "}
                </Text>
                <TouchableOpacity onPress={() => router.push("/sign-up")}>
                  <Text
                    style={{
                      color: Colors.RED,
                      marginTop: 30,
                    }}
                  >
                    Kayıt Ol
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </ImageBackground>
        </ScrollView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

export default SignIn;
