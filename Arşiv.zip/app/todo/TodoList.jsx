import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Alert,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  ActivityIndicator,
} from "react-native";
import {
  addDoc,
  collection,
  getDocs,
  query,
  deleteDoc,
  doc,
  updateDoc,
} from "firebase/firestore";
import { database } from "../../config/firebaseConfig";
import { Colors } from "../../constants/Colors";
import TodoItems from "../../components/TodoList/TodoItems";

const TodoList = () => {
  const [task, setTask] = useState(null);
  const [taskItems, setTaskItems] = useState([]);
  const [editingTaskId, setEditingTaskId] = useState(null);

  useEffect(() => {
    getTodoList();
  }, []);


  const handleAddTask = async () => {
    if (task === "") {
      Alert.alert("Lütfen bir görev girin!");
      return;
    }
    try {
      const docRef = await addDoc(collection(database, "Todo"), {
        task: task,
        createdAt: new Date(),
      });
      console.log("Document written with ID: ", docRef.id);
      setTaskItems((prev) => [
        ...prev,
        { id: docRef.id, task: task, createdAt: new Date() },
      ]);
      setTask(null);
    } catch (error) {
      console.error("Error adding document: ", error);
    }
  };

  const getTodoList = async () => {
    const q = query(collection(database, "Todo"));
    const querySnapshot = await getDocs(q);
    const items = [];
    querySnapshot.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() });
    });
    setTaskItems(items);
  };

  const onDelete = (taskId) => {
    Alert.alert(
      "Silmek istiyor musun?",
      "Bu todoyu silmek istediğine emin misin?",
      [
        {
          text: "İptal",
          style: "cancel",
        },
        {
          text: "Sil",
          style: "default",
          onPress: () => handleDeleteTask(taskId),
        },
      ]
    );
  };

  const handleDeleteTask = async (taskId) => {
    try {
      await deleteDoc(doc(database, "Todo", taskId));
      setTaskItems((prev) => prev.filter((task) => task.id !== taskId));
    } catch (error) {
      console.error("Error deleting document: ", error);
    }
  };

  const handleEditTask = async (taskId, updatedTask) => {
    try {
      await updateDoc(doc(database, "Todo", taskId), {
        task: updatedTask,
      });
      setTaskItems((prev) =>
        prev.map((task) =>
          task.id === taskId ? { ...task, task: updatedTask } : task
        )
      );
      setEditingTaskId(null); 
      Alert.alert("Başarılı", "Görev başarıyla güncellendi!");
    } catch (error) {
      console.error("Error updating document: ", error);
    }
  };

  const handleStartEdit = (taskId) => {
    Alert.alert("Önemli","Düzenlemek istediğiniz todonun üstüne tıklayın!")
    setEditingTaskId(taskId);
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={{ flex: 1 }}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            gap: 15,
          }}
        >
          <Text
            style={{
              marginTop: 150,
              textAlign: "center",
              fontFamily: "fExtraBold",
              fontSize: 25,
              color: Colors.RED,
            }}
          >
            To - do
          </Text>
          <View style={{ alignItems: "center" }}>
            <View
              style={{
                position: "absolute",
                bottom: 90,
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <View
                style={{
                  backgroundColor: Colors.WHITE,
                  width: 220,
                  height: 55,
                  borderRadius: 20,
                  borderWidth: 2,
                  borderColor: Colors.RED,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <TextInput
                  placeholder="Bir To-Do Girin..."
                  placeholderTextColor={"rgba(9,9,9,0.4)"}
                  onChangeText={(text) => setTask(text)}
                  value={task}
                />
              </View>
              <TouchableOpacity
                onPress={handleAddTask}
                style={{
                  backgroundColor: Colors.YELLOW,
                  margin: 20,
                  paddingVertical: 5,
                  borderRadius: 20,
                  width: 60,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Text style={{ color: Colors.RED, fontSize: 40 }}>+</Text>
              </TouchableOpacity>
            </View>
            <View style={{ maxHeight: 800 }}>
              <FlatList
                data={taskItems}
                renderItem={({ item }) => (
                  <TodoItems
                    task={item}
                    onDelete={onDelete}
                    onEdit={handleEditTask}
                    editingTaskId={editingTaskId} 
                    onStartEdit={handleStartEdit} 
                  />
                )}
                keyExtractor={(item) => item.id}
              />
            </View>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

export default TodoList;
