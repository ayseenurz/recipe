import { View, Text, FlatList } from "react-native";
import React, { useEffect, useState } from "react";
import { collection, getDocs, query, where } from "firebase/firestore";
import { database } from "../../config/firebaseConfig";
import RecipeListCard from "../../components/Explore/RecipeListCard";
import SearchBar from "../../components/Search/SearchBar";

const Query = () => {
  const [recipeList, setRecipeList] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (query) {
      getRecipesBySearch();
    }
  }, [query]);

  const getRecipesBySearch = async () => {
    setLoading(true);
    setRecipeList([]);
    try {
      const q = query(collection(database, "RecipeList"),where("name","==",query));
      const querySnapshot = await getDocs(q);
  
      querySnapshot.forEach((doc) => {
        setRecipeList((prev) => [...prev, { id: doc.id, ...doc.data() }]);
        setLoading(false);
      });
    } catch (error) {
      console.log("Error","cant search")
    }
    setLoading(false)
  };

  return (
    <View>
      <FlatList
        data={recipeList}
        renderItem={({ item }) => (
          <RecipeListCard recipe={item} key={item.id} />
        )}
        ListHeaderComponent={() => (
          <View className="flex my-6 px-4">
            <Text className="font-pmedium text-gray-100 text-sm">
              Search Results
            </Text>
            <Text className="text-2xl font-psemibold text-white mt-1">
              {query}
            </Text>
            <View className="mt-6 mb-8">
              <SearchBar />
            </View>
          </View>
        )}
        ListEmptyComponent={() => (
          <EmptyState
            title="Herhangi bir tarif bulunamadı."
            subtitle="Aradığınız tarifi bulmak için anahtar kelimeler giriniz..."
          />
        )}
      />
    </View>
  );
};

export default Query;
