import { View, Text, ScrollView, ActivityIndicator } from "react-native";
import React, { useState, useCallback } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import SearchBar from "../../components/Search/SearchBar";
import Categories from "../../components/Category/Categories";
import { collection, getDocs, query, where } from "firebase/firestore";
import { database } from "../../config/firebaseConfig";
import ExploreRecipeListCard from "../../components/Explore/ExploreRecipeListCard";
import { Colors } from "../../constants/Colors";

const Search = () => {
  const [recipeList, setRecipeList] = useState([]);
  const [loading, setLoading] = useState(false);

  const getRecipeByCategory = useCallback(async (category) => {
    setLoading(true);
    setRecipeList([]);
    try {
      const q = query(
        collection(database, "RecipeList"),
        where("category", "==", category)
      );
      const querySnapshot = await getDocs(q);

      const recipes = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setRecipeList(recipes);
    } catch (error) {
      console.error("Error fetching recipes: ", error);
    } finally {
      setLoading(false);
    }
  }, []);

  return (
      <SafeAreaView style={{ flex: 1 }}>
        <Text style={{ fontFamily: "fExtraBold", fontSize: 40, paddingLeft: 20 }}>
          Explore
        </Text>
        <SearchBar />
        <Categories searching={true} onCategorySelect={getRecipeByCategory} />
        {loading ? (
          <ActivityIndicator size="large" color={Colors.RED} style={{
              marginTop:'60%'
          }}/>
        ) : (
          <ExploreRecipeListCard recipeList={recipeList} />
        )}
      </SafeAreaView>
  );
};

export default Search;
