import { ScrollView } from "react-native";
import React, { useEffect, useState } from "react";
import useAuth from "../../hooks/useAuth";
import Categories from "../../components/Category/Categories";
import PopularRecipes from "../../components/PopularRecipes/PopularRecipes";
import Header from "../../components/Header";
import NewRecipes from "../../components/NewRecipes/NewRecipes";
import MySplashScreen from "../../components/MySplashScreen";


const Home = () => {
  const [loading,setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    // Simulate data loading
    const loadData = async () => {
      // Simulate a data fetching delay
      await new Promise((resolve) => setTimeout(resolve, 1500));
      setLoading(false);
    };

    loadData();
  }, []);

  if (loading) {
    return <MySplashScreen />;
  }
  if (user) {
      return (
        <ScrollView>
          {/* başlık */}
          <Header />
          {/* popüler tarifler */}
          <PopularRecipes />
          {/* kategoriler */}
          <Categories />
          {/* en yeni tarifler */}
          <NewRecipes />
        </ScrollView>
      );
  }
};

export default Home;
