import React, { useState } from "react";
import { View, Text, TouchableOpacity, Image, TextInput } from "react-native";
import { Colors } from "../../constants/Colors";

const TodoItems = ({ task, onDelete, onEdit, editingTaskId, onStartEdit }) => {
  const [updatedTask, setUpdatedTask] = useState(task.task);

  const handleUpdateTask = () => {
    onEdit(task.id, updatedTask);
  };

  return (
    <View>
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: Colors.WHITE,
            width: 340,
            height: 80,
            borderRadius: 20,
            borderWidth: 2,
            borderColor: Colors.RED,
          }}
        >
          <Image
            source={require("../../assets/icons/pin.png")}
            style={{
              backgroundColor: Colors.WHITE,
              height: 40,
              width: 40,
              margin: 20,
            }}
          />
          {editingTaskId === task.id ? (
            <TextInput
              value={updatedTask}
              onChangeText={setUpdatedTask}
              style={{
                fontFamily: "fLight",
                fontSize: 18,
                padding: 10,
                flex: 1,
              }}
            />
          ) : (
            <Text
              style={{
                fontFamily: "fLight",
                fontSize: 18,
                padding: 10,
                flex: 1,
              }}
            >
              {task.task}
            </Text>
          )}
          <View
            style={{
              display:'flex',
              flexDirection:'row',
              justifyContent: "center",
              alignItems: "center",
              gap: 8,
              margin: 10,
            }}
          >
            {editingTaskId === task.id ? (
              <TouchableOpacity onPress={handleUpdateTask}>
                <Image
                  source={require("../../assets/icons/save.png")}
                  style={{
                    width: 24,
                    height: 24,
                  }}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity onPress={() => onStartEdit(task.id)}>
                <Image
                  source={require("../../assets/icons/edit.png")}
                  style={{
                    width: 24,
                    height: 24,
                  }}
                />
              </TouchableOpacity>
            )}
            <TouchableOpacity onPress={() => onDelete(task.id)}>
              <Image
                source={require("../../assets/icons/delete.png")}
                style={{
                  width: 30,
                  height: 30,
                }}
              />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
};

export default TodoItems;
