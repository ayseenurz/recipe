import {
  View,
  Text,
  TextInput,
  Image,
  Alert,
  TouchableOpacity,
} from "react-native";
import React, { useState } from "react";
import { Colors } from "../../constants/Colors";
import { router, usePathname } from "expo-router";

const SearchBar = () => {
  const pathname = usePathname();
  const [query, setQuery] = useState("");
  return (
    <View
      style={{
        marginBottom: 110,
      }}
    >
      <View
        style={{
          padding: 17,
          borderRadius: 20,
          borderWidth: 3,
          borderColor: Colors.YELLOW,
          margin: 20,
          width: 350,
          justifyContent: "space-between",
          display: "flex",
          flexDirection: "row",
          position: "absolute",
        }}
      >
        <TextInput
          placeholder="Ne arıyorsun ?"
          value={query}
          placeholderTextColor={Colors.YELLOW}
          onChangeText={(e) => setQuery(e)}
        />
        <TouchableOpacity
          onPress={() => {
            if (!query) {
              Alert.alert("Uyarı", "Lütfen anahtar kelimeler giriniz !");
            } else {
              if (pathname.startsWith("/search")) router.setParams({ query });
              else router.push(`/search/${query}`);
            }
          }}
        >
          <Image
            source={require("../../assets/icons/search.png")}
            style={{
              width: 25,
              height: 25,
              opacity: 0.3,
            }}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default SearchBar;
