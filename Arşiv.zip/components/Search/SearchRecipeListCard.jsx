import { View, Text } from 'react-native'
import React from 'react'

const SearchRecipeListCard = () => {
  return (
    <View>
      <Text>SearchRecipeListCard</Text>
    </View>
  )
}

export default SearchRecipeListCard