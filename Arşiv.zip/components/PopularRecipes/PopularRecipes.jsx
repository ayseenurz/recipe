import {
  Image,
  StyleSheet,
  Text,
  View,
  FlatList,
  ActivityIndicator,
} from "react-native";
import React, { useEffect, useState } from "react";
import { collection, getDocs, limit, query } from "firebase/firestore";
import PopularRecipesCard from "../PopularRecipes/PopularRecipesCard";
import { database } from "../../config/firebaseConfig";

const PopularRecipes = () => {
  const [recipeList, setRecipeList] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getPopularRecipeList();
  }, []);

  const getPopularRecipeList = async () => {
    setRecipeList([]);
    const q = query(collection(database, "RecipeList"), limit(6));
    const querySnapshot = await getDocs(q);

    querySnapshot.forEach((doc) => {
      setRecipeList((prev) => [...prev, { id: doc.id, ...doc.data() }]);
    });
    setLoading(false);
  };

  return (
    <View>
      <View
        style={{
          paddingLeft: 10,
          marginBottom: 10,
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          marginTop: 5,
        }}
      >
        <Text
          style={{
            fontFamily: "fMedium",
            fontSize: 22,
            padding: 10,
          }}
        >
          Popüler Tarifler
        </Text>
      </View>
    {loading ? <ActivityIndicator size={"small"}/> :
      <FlatList
        data={recipeList}
        horizontal
        showsHorizontalScrollIndicator={false}
        renderItem={({ item, index }) => (
          <PopularRecipesCard key={index} recipe={item} />
        )}
      />}
    </View>
  );
};

export default PopularRecipes;
