import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import React, { useState } from "react";
import { useRouter } from "expo-router";
import useAuth from "../../hooks/useAuth";
import { Colors } from "../../constants/Colors";

const Intro = ({ recipe }) => {
  const router = useRouter();
  const { user } = useAuth();
  return (
    <View
      style={{
        backgroundColor: Colors.WHITE,
      }}
    >
      <View
        style={{
          position: "absolute",
          zIndex: 1,
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          width: "100%",
          marginTop: 20,
          padding: 15,
        }}
      >
        <TouchableOpacity onPress={() => router.back()}
          style={{
            width:60,
            height:0
          }}>
          <Image
            source={require("../../assets/icons/arrow.png")}
            style={{
              width: 30,
              height: 30,
            }}
          />
        </TouchableOpacity>
      </View>
      <Image
        source={{ uri: recipe?.imageUrl }}
        style={{
          width: "100%",
          height: 250,
        }}
      />

      <ScrollView
        style={{
          marginTop: -30,
          borderTopLeftRadius: 30,
          borderTopRightRadius: 30,
          backgroundColor: Colors.WHITE,
        }}
      >
        <View
          style={{
            backgroundColor: Colors.WHITE,
          }}
        >
          <Text
            style={{
              fontFamily: "fBold",
              fontSize: 30,
              textAlign: "center",
              padding: 20,
              color: Colors.RED,
            }}
          >
            {recipe?.name}
          </Text>
        </View>
        <View
          style={{
            backgroundColor: Colors.WHITE,
          }}
        >
          <Text
            style={{
              fontFamily: "fBold",
              fontSize: 20,
              textAlign: "center",

              color: Colors.GRAY,
            }}
          >
            {recipe?.category}
          </Text>
        </View>
      </ScrollView>
    </View>
  );
};

export default Intro;
