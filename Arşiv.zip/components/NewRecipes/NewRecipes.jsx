import { ActivityIndicator, FlatList, StyleSheet, Text, View } from "react-native";
import React, { useEffect, useState } from "react";
import PopularRecipesCard from "../PopularRecipes/PopularRecipesCard";
import { collection, getDocs, limit, orderBy, query } from "firebase/firestore";
import { database } from "../../config/firebaseConfig";
import NewRecipesListCard from "./NewRecipesListCard";

const NewRecipes = () => {
  const [recipeList, setRecipeList] = useState([]);
  const [loading,setLoading] = useState(true);

  useEffect(() => {
    getNewRecipeList();
  }, []);

  const getNewRecipeList = async () => {
    setRecipeList([]);
    const q = query(collection(database, "RecipeList"),orderBy("createdAt", "desc"),limit(6));
    const querySnapshot = await getDocs(q);

    querySnapshot.forEach((doc) => {
      setRecipeList((prev) => [...prev, { id: doc.id, ...doc.data() }]);
      setLoading(false);
    });
  };

  return (
    <View>
      <View
        style={{
          marginBottom: 10,
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          marginTop: 5,
        }}
      >
        <Text
          style={{
            fontFamily: "fMedium",
            fontSize: 22,
            padding: 20,
          }}
        >
          En Yeniler
        </Text>
      </View>
      {loading ? <ActivityIndicator size={"small"}/>: 
      <FlatList
        data={recipeList}
        horizontal
        showsHorizontalScrollIndicator={false}
        renderItem={({ item, index }) => (
          <NewRecipesListCard key={index} recipe={item} />
        )}
      />}
    </View>
  );
};

export default NewRecipes;
