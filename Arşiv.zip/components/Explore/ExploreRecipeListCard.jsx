import { View, Text, FlatList, ScrollView } from "react-native";
import React from "react";
import RecipeListCard from "./RecipeListCard";

const ExploreRecipeListCard = ({ recipeList }) => {
  return (
    <View>
      <FlatList
        data={recipeList}
        renderItem={({ item }) => (
          <RecipeListCard
            key={item.id}
            recipe={item}
            ListEmptyComponent={
              <Text
                style={{
                  textAlign: "center",
                  marginTop: 20,
                  fontSize: 16,
                  color: "#888",
                }}
              >
                No recipes found
              </Text>
            }
          />
        )}
      />
    </View>
  );
};

export default ExploreRecipeListCard;
